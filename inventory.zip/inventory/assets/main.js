$(document).ready(function () {
  /* =====================================================
       SIDEBAR TOGGLE
       ===================================================== */
  const $body = $("body");
  const $sidebar = $("#sidebar");
  const isMobile = () => window.innerWidth <= 768;

  $("#toggleSidebar").on("click", function () {
    if (isMobile()) {
      $sidebar.toggleClass("open");
    } else {
      $body.toggleClass("sidebar-collapsed");
    }
  });

  // Klik di luar sidebar → tutup (mobile)
  $(document).on("click", function (e) {
    if (isMobile() && $sidebar.hasClass("open")) {
      if (!$sidebar.is(e.target) && $sidebar.has(e.target).length === 0) {
        $sidebar.removeClass("open");
      }
    }
  });

  // Reset saat resize ke desktop
  $(window).on("resize", function () {
    if (!isMobile()) {
      $sidebar.removeClass("open");
    }
  });

  /* =====================================================
       AUTO-DISMISS ALERTS
       ===================================================== */
  setTimeout(function () {
    $(".alert").fadeOut(400);
  }, 4000);

  /* =====================================================
       MODAL
       ===================================================== */

  // Buka modal
  $(document).on("click", "[data-modal]", function () {
    const target = $(this).data("modal");
    $("#" + target).addClass("active");
  });

  // Tutup modal via tombol close
  $(document).on("click", '.modal-close, [data-dismiss="modal"]', function () {
    $(this).closest(".modal-overlay").removeClass("active");
  });

  // Tutup modal klik overlay
  $(document).on("click", ".modal-overlay", function (e) {
    if ($(e.target).hasClass("modal-overlay")) {
      $(this).removeClass("active");
    }
  });

  // Tutup modal via ESC
  $(document).on("keydown", function (e) {
    if (e.key === "Escape") {
      $(".modal-overlay.active").removeClass("active");
    }
  });

  /* =====================================================
       CONFIRM DELETE
       ===================================================== */
  $(document).on("click", "[data-confirm]", function (e) {
    const msg = $(this).data("confirm") || "Yakin ingin menghapus data ini?";
    if (!confirm(msg)) {
      e.preventDefault();
    }
  });

  /* =====================================================
       AKTIFKAN TOOLTIP SEDERHANA (title attribute)
       ===================================================== */
  // Native browser tooltip sudah cukup via title=""
  // Tambahkan logika custom tooltip di sini jika diperlukan
});
