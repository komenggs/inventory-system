<?php
// ============================================
// KONFIGURASI DATABASE
// Sesuaikan dengan setting XAMPP Anda
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');           // Kosong untuk XAMPP default
define('DB_NAME', 'inventory_system');
define('APP_NAME', 'Gudang Mengs');
define('APP_VERSION', '1.0.0');

// Base URL otomatis dari folder aplikasi di htdocs (mis. /inventory)
$docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$appRoot = realpath(__DIR__) ?: __DIR__;
if ($docRoot && str_starts_with(str_replace('\\', '/', $appRoot), str_replace('\\', '/', $docRoot))) {
    define('BASE_URL', rtrim(str_replace('\\', '/', substr($appRoot, strlen($docRoot))), '/'));
} else {
    define('BASE_URL', '/inventory');
}

function base_url(string $path = ''): string {
    $path = ltrim(str_replace('\\', '/', $path), '/');
    return BASE_URL . ($path !== '' ? '/' . $path : '');
}

// Koneksi Database
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false
        ]
    );
} catch (PDOException $e) {
    // Log error ke file, jangan tampilkan detail ke user
    error_log('[DB Error] ' . $e->getMessage());
    die('<div style="font-family:sans-serif;padding:40px;text-align:center;">
        <h2 style="color:#e74c3c;">&#10060; Koneksi Database Gagal</h2>
        <p>Pastikan XAMPP MySQL sudah berjalan dan database <strong>' . DB_NAME . '</strong> sudah dibuat.</p>
    </div>');
}

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function redirect(string $path) {
    if (preg_match('#^https?://#i', $path)) {
        header('Location: ' . $path);
    } elseif ($path !== '' && $path[0] === '/') {
        header('Location: ' . BASE_URL . $path);
    } else {
        header('Location: ' . base_url($path));
    }
    exit();
}

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function formatRupiah($angka) {
    return 'Rp ' . number_format((float)$angka, 0, ',', '.');
}

function generateKodeTransaksi($tipe) {
    $prefix = $tipe === 'masuk' ? 'TM' : 'TK';
    return $prefix . '-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
}

function getStokStatus($stok, $minimum) {
    if ($stok == 0) return ['label' => 'Habis',   'class' => 'badge-danger'];
    if ($stok <= $minimum) return ['label' => 'Menipis', 'class' => 'badge-warning'];
    return ['label' => 'Aman', 'class' => 'badge-success'];
}

// Proteksi halaman
function requireLogin() {
    if (!isLoggedIn()) {
        redirect('index.php');
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        redirect('pages/dashboard.php');
    }
}

// ============================================
// CSRF PROTECTION
// ============================================

function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken() {
    $token = $_POST['csrf_token'] ?? '';
    if (empty($token) || $token !== ($_SESSION['csrf_token'] ?? '')) {
        http_response_code(403);
        die('<div style="font-family:sans-serif;padding:40px;text-align:center;">
            <h2 style="color:#e74c3c;">&#10060; Akses Ditolak</h2>
            <p>Token keamanan tidak valid. Silakan <a href="javascript:history.back()">kembali</a> dan coba lagi.</p>
        </div>');
    }
}

// Field CSRF untuk ditaruh di dalam form
function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . generateCsrfToken() . '">';
}
?>