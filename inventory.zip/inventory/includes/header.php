<?php
// requireLogin() sudah dipanggil di masing-masing halaman
$currentUser = $_SESSION;
$currentPage = basename($_SERVER['PHP_SELF']);

/**
 * Helper: tambahkan class 'active' jika halaman saat ini cocok
 */
function navActive(string $filename): string {
    return basename($_SERVER['PHP_SELF']) === $filename ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — ' : '' ?>
        <?= APP_NAME ?>
    </title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <!-- App Stylesheet -->
    <link href="<?= base_url('assets/style.css') ?>" rel="stylesheet">

    <!-- jQuery (harus dimuat sebelum script inline di halaman) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body>

<!-- ===== SIDEBAR ===== -->
<aside class="sidebar" id="sidebar">

    <!-- Brand -->
    <div class="sidebar-brand">
        <div class="brand-icon">
            <i class="fas fa-boxes-stacked"></i>
        </div>
        <div class="brand-text">
            <span class="brand-name"><?= APP_NAME ?></span>
            <span class="brand-sub">Sistem Inventory</span>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="sidebar-nav">

        <!-- Utama -->
        <div class="nav-section">
            <span class="nav-label">Utama</span>

            <a href="<?= base_url('pages/dashboard.php') ?>" class="nav-item <?= navActive('dashboard.php') ?>">
                <i class="fas fa-gauge-high"></i>
                <span>Dashboard</span>
            </a>
            <a href="<?= base_url('pages/barang.php') ?>" class="nav-item <?= navActive('barang.php') ?>">
                <i class="fas fa-boxes"></i>
                <span>Data Barang</span>
            </a>
            <a href="<?= base_url('pages/kategori.php') ?>" class="nav-item <?= navActive('kategori.php') ?>">
                <i class="fas fa-tags"></i>
                <span>Kategori</span>
            </a>
        </div>

        <!-- Transaksi -->
        <div class="nav-section">
            <span class="nav-label">Transaksi</span>

            <a href="<?= base_url('pages/transaksi_masuk.php') ?>" class="nav-item <?= navActive('transaksi_masuk.php') ?>">
                <i class="fas fa-arrow-down"></i>
                <span>Barang Masuk</span>
            </a>
            <a href="<?= base_url('pages/transaksi_keluar.php') ?>" class="nav-item <?= navActive('transaksi_keluar.php') ?>">
                <i class="fas fa-arrow-up"></i>
                <span>Barang Keluar</span>
            </a>
            <a href="<?= base_url('pages/riwayat.php') ?>" class="nav-item <?= navActive('riwayat.php') ?>">
                <i class="fas fa-clock-rotate-left"></i>
                <span>Riwayat Transaksi</span>
            </a>
        </div>

        <!-- Laporan -->
        <div class="nav-section">
            <span class="nav-label">Laporan</span>

            <a href="<?= base_url('pages/laporan.php') ?>" class="nav-item <?= navActive('laporan.php') ?>">
                <i class="fas fa-chart-bar"></i>
                <span>Laporan</span>
            </a>
        </div>

        <!-- Admin (hanya tampil untuk role admin) -->
        <?php if (isAdmin()): ?>
        <div class="nav-section">
            <span class="nav-label">Admin</span>

            <a href="<?= base_url('pages/admin/users.php') ?>" class="nav-item <?= navActive('users.php') ?>">
                <i class="fas fa-users-gear"></i>
                <span>Kelola User</span>
            </a>
        </div>
        <?php endif; ?>

    </nav>

    <!-- Sidebar Footer: Info User + Logout -->
    <div class="sidebar-footer">
        <div class="user-info">
            <div class="user-avatar">
                <?= strtoupper(substr($currentUser['nama'], 0, 1)) ?>
            </div>
            <div class="user-detail">
                <span class="user-name"><?= htmlspecialchars($currentUser['nama']) ?></span>
                <span class="user-role"><?= ucfirst($currentUser['role']) ?></span>
            </div>
        </div>
        <a href="<?= base_url('logout.php') ?>" class="btn-logout" title="Logout">
            <i class="fas fa-right-from-bracket"></i>
        </a>
    </div>

</aside>
<!-- ===== END SIDEBAR ===== -->


<!-- ===== MAIN WRAPPER ===== -->
<div class="main-wrapper">

    <!-- Top Bar -->
    <header class="topbar">
        <button class="toggle-sidebar" id="toggleSidebar" aria-label="Toggle sidebar">
            <i class="fas fa-bars"></i>
        </button>

        <div class="topbar-title">
            <?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Dashboard' ?>
        </div>

        <div class="topbar-right">
            <span class="role-badge <?= $currentUser['role'] === 'admin' ? 'role-admin' : 'role-staff' ?>">
                <i class="fas fa-shield-halved"></i>
                <?= ucfirst($currentUser['role']) ?>
            </span>
            <span class="topbar-date">
                <i class="far fa-calendar"></i>
                <?= date('d M Y') ?>
            </span>
        </div>
    </header>
    <!-- End Top Bar -->

    <!-- Page Content -->
    <div class="page-content">