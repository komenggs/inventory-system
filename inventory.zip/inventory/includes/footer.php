</div><!-- end .page-content -->

</div><!-- end .main-wrapper -->

<!-- App Script -->
<script src="<?= base_url('assets/main.js') ?>"></script>

<!-- Extra JS (opsional, didefinisikan di masing-masing halaman) -->
<?php if (isset($extraJS)) echo $extraJS; ?>

</body>
</html>