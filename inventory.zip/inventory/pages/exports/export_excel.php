<?php
require_once '../../config.php';
requireLogin();

$tipe   = sanitize($_GET['tipe']   ?? '');
$dari   = sanitize($_GET['dari']   ?? date('Y-m-01'));
$sampai = sanitize($_GET['sampai'] ?? date('Y-m-d'));

$cond = "WHERE t.tanggal BETWEEN ? AND ?";
$params = [$dari, $sampai];
if ($tipe) { $cond .= " AND t.tipe=?"; $params[] = $tipe; }

$transaksis = $pdo->prepare("
    SELECT t.no_transaksi, t.tipe, t.tanggal, t.keterangan,
           u.nama as user_nama,
           GROUP_CONCAT(CONCAT(b.nama_barang,'(',dt.jumlah,' ',b.satuan,')') SEPARATOR ', ') as barang_list,
           SUM(dt.subtotal) as total_nilai,
           COUNT(dt.id) as jumlah_item
    FROM transaksi t
    LEFT JOIN users u ON t.user_id=u.id
    LEFT JOIN detail_transaksi dt ON t.id=dt.transaksi_id
    LEFT JOIN barang b ON dt.barang_id=b.id
    $cond GROUP BY t.id ORDER BY t.tanggal DESC, t.created_at DESC
");
$transaksis->execute($params);
$rows = $transaksis->fetchAll();

// Generate Excel (HTML table dengan header Content-Disposition)
$namaFile = 'Transaksi_' . ($tipe ?: 'Semua') . '_' . $dari . '_sd_' . $sampai . '.xls';

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
header('Pragma: no-cache');
header('Expires: 0');
?>
<html><head>
<meta charset="UTF-8">
<style>
    body { font-family: Arial, sans-serif; font-size: 11px; }
    table { border-collapse: collapse; width: 100%; }
    th { background: #1a56db; color: white; padding: 8px; border: 1px solid #ddd; font-weight: bold; }
    td { padding: 6px 8px; border: 1px solid #ddd; }
    tr:nth-child(even) td { background: #f5f5f5; }
    .title { font-size: 16px; font-weight: bold; color: #1a56db; margin-bottom: 4px; }
    .subtitle { color: #666; font-size: 11px; margin-bottom: 12px; }
    .total-row td { background: #e8f0fe; font-weight: bold; }
</style>
</head><body>
<div class="title">📦 Gudang Mengs — Laporan Transaksi</div>
<div class="subtitle">Periode: <?= date('d/m/Y',strtotime($dari)) ?> s/d <?= date('d/m/Y',strtotime($sampai)) ?>
    <?= $tipe ? ' | Tipe: '.ucfirst($tipe) : '' ?>
    | Dicetak: <?= date('d/m/Y H:i') ?>
</div>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>No. Transaksi</th>
            <th>Tipe</th>
            <th>Tanggal</th>
            <th>Jumlah Item</th>
            <th>Barang</th>
            <th>Total Nilai (Rp)</th>
            <th>Keterangan</th>
            <th>Dibuat Oleh</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $no = 1; $grandTotal = 0;
    foreach ($rows as $r):
        $grandTotal += $r['total_nilai'];
    ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $r['no_transaksi'] ?></td>
        <td><?= ucfirst($r['tipe']) ?></td>
        <td><?= date('d/m/Y', strtotime($r['tanggal'])) ?></td>
        <td><?= $r['jumlah_item'] ?></td>
        <td><?= htmlspecialchars($r['barang_list'] ?? '-') ?></td>
        <td style="text-align:right"><?= number_format($r['total_nilai'],0,',','.') ?></td>
        <td><?= htmlspecialchars($r['keterangan'] ?? '') ?></td>
        <td><?= htmlspecialchars($r['user_nama'] ?? '-') ?></td>
    </tr>
    <?php endforeach; ?>
    <tr class="total-row">
        <td colspan="6" style="text-align:right;font-weight:bold">GRAND TOTAL</td>
        <td style="text-align:right;font-weight:bold"><?= number_format($grandTotal,0,',','.') ?></td>
        <td colspan="2"></td>
    </tr>
    </tbody>
</table>

<br>
<div style="font-size:10px;color:#999">File ini digenerate otomatis oleh Gudang Mengs</div>
</body></html>