<?php
require_once '../../config.php';
requireLogin();

$tipe   = sanitize($_GET['tipe']   ?? '');
$dari   = sanitize($_GET['dari']   ?? date('Y-m-01'));
$sampai = sanitize($_GET['sampai'] ?? date('Y-m-d'));

$cond = "WHERE t.tanggal BETWEEN ? AND ?";
$params = [$dari, $sampai];
if ($tipe) { $cond .= " AND t.tipe=?"; $params[] = $tipe; }

$stmt = $pdo->prepare("
    SELECT t.*, u.nama as user_nama,
           SUM(dt.subtotal) as total_nilai,
           COUNT(dt.id) as jumlah_item
    FROM transaksi t
    LEFT JOIN users u ON t.user_id=u.id
    LEFT JOIN detail_transaksi dt ON t.id=dt.transaksi_id
    $cond GROUP BY t.id ORDER BY t.tanggal DESC
");
$stmt->execute($params);
$rows = $stmt->fetchAll();
$grandTotal = array_sum(array_column($rows, 'total_nilai'));

// Stok barang
$stokBarang = $pdo->query("SELECT b.*, k.nama_kategori FROM barang b LEFT JOIN kategori k ON b.kategori_id=k.id ORDER BY b.nama_barang")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Inventory</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: Arial, sans-serif; font-size: 12px; color: #111; }
        .page { padding: 24px; }
        .header { text-align:center; border-bottom:3px solid #1a56db; padding-bottom:14px; margin-bottom:20px; }
        .header h1 { font-size:20px; color:#1a56db; font-weight:bold; }
        .header p { color:#555; font-size:11px; margin-top:3px; }
        .meta { display:flex; justify-content:space-between; background:#f0f7ff; padding:10px 14px; border-radius:6px; margin-bottom:18px; font-size:11px; }
        h2 { font-size:13px; color:#1a56db; margin-bottom:10px; border-left:4px solid #1a56db; padding-left:8px; }
        table { width:100%; border-collapse:collapse; margin-bottom:20px; font-size:11px; }
        th { background:#1a56db; color:white; padding:7px 9px; text-align:left; }
        td { padding:6px 9px; border-bottom:1px solid #e5e7eb; }
        tr:nth-child(even) td { background:#f9fafb; }
        .total-row td { background:#dbeafe; font-weight:bold; border-top:2px solid #1a56db; }
        .badge { display:inline-block; padding:2px 8px; border-radius:99px; font-size:10px; font-weight:bold; }
        .masuk { background:#d1fae5; color:#065f46; }
        .keluar { background:#dbeafe; color:#1e40af; }
        .habis { background:#fee2e2; color:#991b1b; }
        .menipis { background:#fef3c7; color:#92400e; }
        .aman { background:#d1fae5; color:#065f46; }
        .footer { margin-top:20px; font-size:10px; color:#9ca3af; text-align:center; border-top:1px solid #e5e7eb; padding-top:10px; }
        @media print {
            @page { size: A4; margin: 1.5cm; }
            body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body>
<div class="page">

<div class="header">
    <h1>&#128230; Gudang Mengs — Laporan Inventory</h1>
    <p>Sistem Manajemen Inventory Terpadu</p>
</div>

<div class="meta">
    <span><b>Periode:</b> <?= date('d/m/Y',strtotime($dari)) ?> s/d <?= date('d/m/Y',strtotime($sampai)) ?></span>
    <span><b>Tipe:</b> <?= $tipe ? ucfirst($tipe) : 'Semua' ?></span>
    <span><b>Dicetak:</b> <?= date('d/m/Y H:i') ?></span>
    <span><b>Oleh:</b> <?= htmlspecialchars($_SESSION['nama']) ?></span>
</div>

<h2>Rekapitulasi Transaksi</h2>
<table>
    <thead>
        <tr><th>No</th><th>No. Transaksi</th><th>Tipe</th><th>Tanggal</th><th>Item</th><th>Total Nilai</th><th>Keterangan</th><th>Oleh</th></tr>
    </thead>
    <tbody>
    <?php $no=1; foreach ($rows as $r): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $r['no_transaksi'] ?></td>
        <td><span class="badge <?= $r['tipe'] ?>"><?= ucfirst($r['tipe']) ?></span></td>
        <td><?= date('d/m/Y',strtotime($r['tanggal'])) ?></td>
        <td style="text-align:center"><?= $r['jumlah_item'] ?></td>
        <td style="text-align:right">Rp <?= number_format($r['total_nilai'],0,',','.') ?></td>
        <td><?= htmlspecialchars(substr($r['keterangan']??'',0,30)) ?></td>
        <td><?= htmlspecialchars($r['user_nama']??'-') ?></td>
    </tr>
    <?php endforeach; ?>
    <tr class="total-row">
        <td colspan="5" style="text-align:right">GRAND TOTAL</td>
        <td style="text-align:right">Rp <?= number_format($grandTotal,0,',','.') ?></td>
        <td colspan="2"></td>
    </tr>
    </tbody>
</table>

<h2>Stok Barang Saat Ini</h2>
<table>
    <thead>
        <tr><th>No</th><th>Kode</th><th>Nama Barang</th><th>Kategori</th><th>Satuan</th><th>Stok</th><th>Min Stok</th><th>Status</th><th>Nilai Jual</th></tr>
    </thead>
    <tbody>
    <?php $no=1; foreach ($stokBarang as $b):
        $status = getStokStatus($b['stok'], $b['stok_minimum']);
        $statusClass = $b['stok']==0 ? 'habis' : ($b['stok']<=$b['stok_minimum'] ? 'menipis' : 'aman');
    ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $b['kode_barang'] ?></td>
        <td><?= htmlspecialchars($b['nama_barang']) ?></td>
        <td><?= htmlspecialchars($b['nama_kategori']??'-') ?></td>
        <td><?= $b['satuan'] ?></td>
        <td style="text-align:center;font-weight:bold"><?= $b['stok'] ?></td>
        <td style="text-align:center"><?= $b['stok_minimum'] ?></td>
        <td><span class="badge <?= $statusClass ?>"><?= $status['label'] ?></span></td>
        <td style="text-align:right">Rp <?= number_format($b['harga_jual']*$b['stok'],0,',','.') ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div class="footer">
    Laporan ini digenerate secara otomatis oleh Gudang Mengs v1.0 pada <?= date('d/m/Y H:i:s') ?>
</div>

</div>

<script>window.onload = function(){ window.print(); }</script>
</body>
</html>