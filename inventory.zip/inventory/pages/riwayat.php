<?php
require_once '../config.php';
requireLogin();
$pageTitle = 'Riwayat Transaksi';
$msg = ''; $msgType = '';

// Hapus transaksi (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isAdmin()) {
    verifyCsrfToken();
    $id = (int)$_POST['id'];
    $pdo->beginTransaction();
    try {
        // Kembalikan stok
        $details = $pdo->prepare("SELECT dt.barang_id, dt.jumlah, t.tipe FROM detail_transaksi dt JOIN transaksi t ON dt.transaksi_id=t.id WHERE dt.transaksi_id=?");
        $details->execute([$id]);
        foreach ($details->fetchAll() as $d) {
            if ($d['tipe'] === 'masuk') {
                $pdo->prepare("UPDATE barang SET stok = stok - ? WHERE id=?")->execute([$d['jumlah'],$d['barang_id']]);
            } else {
                $pdo->prepare("UPDATE barang SET stok = stok + ? WHERE id=?")->execute([$d['jumlah'],$d['barang_id']]);
            }
        }
        $pdo->prepare("DELETE FROM transaksi WHERE id=?")->execute([$id]);
        $pdo->commit();
        $msg = 'Transaksi berhasil dihapus dan stok telah dikembalikan.'; $msgType = 'success';
    } catch (Exception $e) {
        $pdo->rollBack();
        $msg = 'Gagal menghapus: ' . $e->getMessage(); $msgType = 'danger';
    }
}

$tipe   = sanitize($_GET['tipe']   ?? '');
$dari   = sanitize($_GET['dari']   ?? '');
$sampai = sanitize($_GET['sampai'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15; $offset = ($page - 1) * $perPage;

$cond   = "WHERE 1=1";
$params = [];
if ($tipe)   { $cond .= " AND t.tipe=?";         $params[] = $tipe; }
if ($dari)   { $cond .= " AND t.tanggal >= ?";    $params[] = $dari; }
if ($sampai) { $cond .= " AND t.tanggal <= ?";    $params[] = $sampai; }

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM transaksi t $cond");
$totalStmt->execute($params);
$totalRows  = $totalStmt->fetchColumn();
$totalPages = ceil($totalRows / $perPage);

$stmt = $pdo->prepare("
    SELECT t.*, u.nama as user_nama, SUM(dt.subtotal) as total_nilai, COUNT(dt.id) as jumlah_item
    FROM transaksi t
    LEFT JOIN users u ON t.user_id=u.id
    LEFT JOIN detail_transaksi dt ON t.id=dt.transaksi_id
    $cond GROUP BY t.id ORDER BY t.tanggal DESC, t.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$transaksis = $stmt->fetchAll();

include '../includes/header.php';
?>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= $msg ?></div><?php endif; ?>

<!-- FILTER -->
<div class="card" style="margin-bottom:20px">
    <div class="card-body" style="padding:16px">
        <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
            <div class="form-group" style="margin:0;min-width:150px">
                <label class="form-label" style="font-size:.78rem">Tipe</label>
                <select name="tipe" class="form-control">
                    <option value="">Semua</option>
                    <option value="masuk"  <?= $tipe==='masuk'?'selected':'' ?>>Masuk</option>
                    <option value="keluar" <?= $tipe==='keluar'?'selected':'' ?>>Keluar</option>
                </select>
            </div>
            <div class="form-group" style="margin:0">
                <label class="form-label" style="font-size:.78rem">Dari Tanggal</label>
                <input type="date" name="dari" class="form-control" value="<?= $dari ?>">
            </div>
            <div class="form-group" style="margin:0">
                <label class="form-label" style="font-size:.78rem">Sampai Tanggal</label>
                <input type="date" name="sampai" class="form-control" value="<?= $sampai ?>">
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
            <a href="riwayat.php" class="btn btn-outline">Reset</a>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-clock-rotate-left"></i> Semua Transaksi</div>
        <div class="export-bar no-print">
            <a href="exports/export_excel.php?tipe=<?= urlencode($tipe) ?>&dari=<?= $dari ?>&sampai=<?= $sampai ?>" class="btn btn-excel btn-sm">
                <i class="fas fa-file-excel"></i> Excel
            </a>
            <a href="exports/export_pdf.php?tipe=<?= urlencode($tipe) ?>&dari=<?= $dari ?>&sampai=<?= $sampai ?>" class="btn btn-pdf-dl btn-sm" target="_blank">
                <i class="fas fa-file-pdf"></i> PDF
            </a>
            <button onclick="window.print()" class="btn btn-print btn-sm">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
    </div>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr><th>No. Transaksi</th><th>Tipe</th><th>Tanggal</th><th>Item</th><th>Total Nilai</th><th>Keterangan</th><th>Oleh</th><th class="no-print">Aksi</th></tr>
            </thead>
            <tbody>
            <?php if ($transaksis): foreach ($transaksis as $tx): ?>
            <tr>
                <td><code style="font-size:.78rem"><?= htmlspecialchars($tx['no_transaksi']) ?></code></td>
                <td>
                    <?php if ($tx['tipe']==='masuk'): ?>
                    <span class="badge badge-success"><i class="fas fa-arrow-down"></i> Masuk</span>
                    <?php else: ?>
                    <span class="badge badge-info"><i class="fas fa-arrow-up"></i> Keluar</span>
                    <?php endif; ?>
                </td>
                <td><?= date('d M Y', strtotime($tx['tanggal'])) ?></td>
                <td><?= $tx['jumlah_item'] ?></td>
                <td style="font-weight:600"><?= formatRupiah($tx['total_nilai'] ?? 0) ?></td>
                <td style="font-size:.82rem;color:var(--gray-500)"><?= htmlspecialchars(substr($tx['keterangan']??'',0,40)) ?></td>
                <td style="font-size:.82rem"><?= htmlspecialchars($tx['user_nama'] ?? '-') ?></td>
                <td class="no-print">
                    <div style="display:flex;gap:4px">
                        <a href="cetak_transaksi.php?id=<?= $tx['id'] ?>" class="btn btn-outline btn-sm" target="_blank"><i class="fas fa-print"></i></a>
                        <?php if (isAdmin()): ?>
                        <form method="POST" style="display:inline">
                            <?= csrfField() ?>
                            <input type="hidden" name="id" value="<?= $tx['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm btn-icon btn-delete"
                                data-nama="transaksi <?= htmlspecialchars($tx['no_transaksi']) ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; else: ?>
            <tr><td colspan="8"><div class="empty-state"><i class="fas fa-clock-rotate-left"></i><h3>Tidak ada transaksi</h3></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
    <div style="padding:12px 20px;border-top:1px solid var(--gray-100)">
        <div class="pagination">
            <?php for ($i=1;$i<=$totalPages;$i++): ?>
            <a href="?page=<?= $i ?>&tipe=<?= urlencode($tipe) ?>&dari=<?= $dari ?>&sampai=<?= $sampai ?>" class="page-btn <?= $i==$page?'active':'' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>