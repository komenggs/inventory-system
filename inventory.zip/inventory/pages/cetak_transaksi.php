<?php
require_once '../config.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$tx = $pdo->prepare("SELECT t.*, u.nama as user_nama FROM transaksi t LEFT JOIN users u ON t.user_id=u.id WHERE t.id=?");
$tx->execute([$id]);
$transaksi = $tx->fetch();

if (!$transaksi) die('Transaksi tidak ditemukan.');

$details = $pdo->prepare("SELECT dt.*, b.nama_barang, b.kode_barang, b.satuan FROM detail_transaksi dt JOIN barang b ON dt.barang_id=b.id WHERE dt.transaksi_id=?");
$details->execute([$id]);
$items = $details->fetchAll();

$totalNilai = array_sum(array_column($items, 'subtotal'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi <?= $transaksi['no_transaksi'] ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Plus Jakarta Sans',sans-serif; font-size:13px; color:#111; padding:30px; background:#fff; }
        .header { text-align:center; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid #1a56db; }
        .header h1 { font-size:22px; color:#1a56db; font-weight:800; }
        .header p { color:#6b7280; font-size:12px; }
        .info-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px; }
        .info-box { background:#f8faff; border:1px solid #dbeafe; border-radius:8px; padding:12px; }
        .info-box .label { font-size:11px; color:#6b7280; font-weight:600; text-transform:uppercase; letter-spacing:.05em; }
        .info-box .value { font-size:14px; font-weight:700; color:#111; margin-top:2px; }
        table { width:100%; border-collapse:collapse; margin-bottom:16px; }
        th { background:#1a56db; color:white; padding:9px 12px; text-align:left; font-size:11px; font-weight:700; text-transform:uppercase; }
        td { padding:9px 12px; border-bottom:1px solid #e5e7eb; font-size:12px; }
        tr:nth-child(even) td { background:#f9fafb; }
        .total-row td { background:#f0f7ff; font-weight:700; font-size:13px; border-top:2px solid #1a56db; }
        .badge { display:inline-block; padding:3px 10px; border-radius:99px; font-size:11px; font-weight:700; }
        .badge-masuk { background:#d1fae5; color:#059669; }
        .badge-keluar { background:#dbeafe; color:#1d4ed8; }
        .footer-note { margin-top:30px; padding-top:16px; border-top:1px solid #e5e7eb; display:flex; justify-content:space-between; font-size:11px; color:#9ca3af; }
        .ttd { text-align:center; margin-top:30px; }
        .ttd .ttd-box { display:inline-block; margin:0 40px; text-align:center; }
        .ttd-line { margin-top:50px; border-top:1px solid #374151; padding-top:6px; font-size:11px; }
        @media print {
            .no-print { display:none; }
            body { padding:15px; }
        }
    </style>
</head>
<body>
<div class="no-print" style="margin-bottom:16px;display:flex;gap:8px">
    <button onclick="window.print()" style="padding:8px 16px;background:#1a56db;color:white;border:none;border-radius:6px;cursor:pointer;font-family:inherit;font-weight:600">
        🖨️ Print
    </button>
    <a href="exports/export_pdf_satu.php?id=<?= $id ?>" style="padding:8px 16px;background:#e74c3c;color:white;border-radius:6px;text-decoration:none;font-weight:600">
        📄 Download PDF
    </a>
    <button onclick="window.close()" style="padding:8px 16px;background:#6b7280;color:white;border:none;border-radius:6px;cursor:pointer;font-family:inherit;font-weight:600">
        ✕ Tutup
    </button>
</div>

<div class="header">
    <h1>📦 Gudang Mengs</h1>
    <p>Sistem Manajemen Inventory</p>
    <p style="margin-top:8px;font-size:14px;font-weight:700">
        BUKTI TRANSAKSI <?= strtoupper($transaksi['tipe']) ?>
    </p>
</div>

<div class="info-grid">
    <div class="info-box">
        <div class="label">No. Transaksi</div>
        <div class="value"><?= $transaksi['no_transaksi'] ?></div>
    </div>
    <div class="info-box">
        <div class="label">Tipe</div>
        <div class="value">
            <span class="badge badge-<?= $transaksi['tipe'] ?>"><?= ucfirst($transaksi['tipe']) ?></span>
        </div>
    </div>
    <div class="info-box">
        <div class="label">Tanggal</div>
        <div class="value"><?= date('d MMMM Y', strtotime($transaksi['tanggal'])) ?></div>
    </div>
    <div class="info-box">
        <div class="label">Dibuat Oleh</div>
        <div class="value"><?= htmlspecialchars($transaksi['user_nama'] ?? '-') ?></div>
    </div>
</div>

<?php if ($transaksi['keterangan']): ?>
<div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:12px">
    <strong>Keterangan:</strong> <?= htmlspecialchars($transaksi['keterangan']) ?>
</div>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Kode</th>
            <th>Nama Barang</th>
            <th>Satuan</th>
            <th style="text-align:right">Qty</th>
            <th style="text-align:right">Harga</th>
            <th style="text-align:right">Subtotal</th>
        </tr>
    </thead>
    <tbody>
    <?php $no=1; foreach ($items as $item): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $item['kode_barang'] ?></td>
        <td><?= htmlspecialchars($item['nama_barang']) ?></td>
        <td><?= $item['satuan'] ?></td>
        <td style="text-align:right"><?= number_format($item['jumlah']) ?></td>
        <td style="text-align:right"><?= formatRupiah($item['harga']) ?></td>
        <td style="text-align:right;font-weight:600"><?= formatRupiah($item['subtotal']) ?></td>
    </tr>
    <?php endforeach; ?>
    <tr class="total-row">
        <td colspan="6" style="text-align:right">TOTAL</td>
        <td style="text-align:right"><?= formatRupiah($totalNilai) ?></td>
    </tr>
    </tbody>
</table>

<div class="ttd">
    <div class="ttd-box">
        <div style="font-size:11px;color:#6b7280">Dibuat oleh,</div>
        <div class="ttd-line"><?= htmlspecialchars($transaksi['user_nama'] ?? '-') ?></div>
    </div>
    <div class="ttd-box">
        <div style="font-size:11px;color:#6b7280">Mengetahui,</div>
        <div class="ttd-line">( ________________________ )</div>
    </div>
</div>

<div class="footer-note">
    <span>Dicetak: <?= date('d/m/Y H:i') ?></span>
    <span>Gudang Mengs v1.0 — Sistem Manajemen Inventory</span>
</div>
</body>
</html>