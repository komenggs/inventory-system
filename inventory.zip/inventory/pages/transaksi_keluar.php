<?php
require_once '../config.php';
requireLogin();
$pageTitle = 'Barang Keluar';

$msg = ''; $msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();

    $tanggal    = $_POST['tanggal'] ?? date('Y-m-d');
    $keterangan = sanitize($_POST['keterangan'] ?? '');
    $barang_ids = $_POST['barang_id'] ?? [];
    $jumlahs    = $_POST['jumlah'] ?? [];
    $hargas     = $_POST['harga'] ?? [];

    // Filter baris kosong dan validasi qty
    $validItems = [];
    foreach ($barang_ids as $i => $bid) {
        if (empty($bid)) continue;
        $qty = (int)$jumlahs[$i];
        if ($qty <= 0) continue;
        $validItems[] = [
            'bid'   => (int)$bid,
            'qty'   => $qty,
            'harga' => max(0, (float)$hargas[$i]),
        ];
    }

    if (empty($validItems)) {
        $msg = 'Minimal satu barang harus dipilih dengan jumlah lebih dari 0.'; $msgType = 'danger';
    } else {
        // Cek stok cukup (gunakan SELECT ... FOR UPDATE dalam transaksi)
        $errors = [];
        $pdo->beginTransaction();
        try {
            foreach ($validItems as $item) {
                $brg = $pdo->prepare("SELECT stok, nama_barang FROM barang WHERE id=? FOR UPDATE");
                $brg->execute([$item['bid']]);
                $b = $brg->fetch();
                if (!$b) {
                    $errors[] = 'Barang tidak ditemukan.';
                } elseif ($item['qty'] > $b['stok']) {
                    $errors[] = "Stok <strong>{$b['nama_barang']}</strong> tidak cukup (tersedia: {$b['stok']}).";
                }
            }

            if ($errors) {
                $pdo->rollBack();
                $msg = implode('<br>', $errors); $msgType = 'danger';
            } else {
                $noTx = generateKodeTransaksi('keluar');
                $pdo->prepare("INSERT INTO transaksi (no_transaksi,tipe,tanggal,keterangan,user_id) VALUES (?,?,?,?,?)")
                    ->execute([$noTx,'keluar',$tanggal,$keterangan,$_SESSION['user_id']]);
                $txId = $pdo->lastInsertId();

                foreach ($validItems as $item) {
                    $subtotal = $item['qty'] * $item['harga'];
                    $pdo->prepare("INSERT INTO detail_transaksi (transaksi_id,barang_id,jumlah,harga,subtotal) VALUES (?,?,?,?,?)")
                        ->execute([$txId,$item['bid'],$item['qty'],$item['harga'],$subtotal]);
                    $pdo->prepare("UPDATE barang SET stok = stok - ? WHERE id=?")
                        ->execute([$item['qty'],$item['bid']]);
                }

                $pdo->commit();
                $msg = "Transaksi keluar <strong>$noTx</strong> berhasil disimpan!"; $msgType = 'success';
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            $msg = 'Gagal menyimpan transaksi: ' . $e->getMessage(); $msgType = 'danger';
        }
    }
}

$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 10;
$offset     = ($page - 1) * $perPage;
$totalRows  = $pdo->query("SELECT COUNT(*) FROM transaksi WHERE tipe='keluar'")->fetchColumn();
$totalPages = ceil($totalRows / $perPage);

$transaksis = $pdo->query("
    SELECT t.*, u.nama as user_nama, SUM(dt.subtotal) as total_nilai, COUNT(dt.id) as jumlah_item
    FROM transaksi t
    LEFT JOIN users u ON t.user_id = u.id
    LEFT JOIN detail_transaksi dt ON t.id = dt.transaksi_id
    WHERE t.tipe='keluar'
    GROUP BY t.id ORDER BY t.created_at DESC LIMIT $perPage OFFSET $offset
")->fetchAll();

$barangs = $pdo->query("SELECT * FROM barang WHERE stok > 0 ORDER BY nama_barang")->fetchAll();

include '../includes/header.php';
?>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= $msg ?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1.2fr;gap:20px">
<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-arrow-up" style="color:#3b82f6"></i> Input Barang Keluar</div>
    </div>
    <div class="card-body">
        <form method="POST">
            <?= csrfField() ?>
            <div class="form-group">
                <label class="form-label">Tanggal <span class="req">*</span></label>
                <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Keterangan</label>
                <textarea name="keterangan" class="form-control" placeholder="Keterangan pengeluaran..."></textarea>
            </div>
            <div style="margin-bottom:12px">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                    <label class="form-label" style="margin:0">Detail Barang <span class="req">*</span></label>
                    <button type="button" id="addRow" class="btn btn-outline btn-sm"><i class="fas fa-plus"></i> Baris</button>
                </div>
                <div style="overflow-x:auto;border-radius:8px;border:1px solid var(--gray-200)">
                    <table id="items-table" style="min-width:540px">
                        <thead>
                            <tr>
                                <th>Barang</th><th style="width:80px">Qty</th>
                                <th style="width:120px">Harga Jual</th><th style="width:110px">Subtotal</th><th style="width:40px"></th>
                            </tr>
                        </thead>
                        <tbody id="items-tbody">
                            <tr class="detail-row">
                                <td>
                                    <select name="barang_id[]" class="form-control barang-select">
                                        <option value="">— Pilih —</option>
                                        <?php foreach ($barangs as $b): ?>
                                        <option value="<?= $b['id'] ?>" data-stok="<?= $b['stok'] ?>" data-satuan="<?= $b['satuan'] ?>" data-harga="<?= $b['harga_jual'] ?>">
                                            <?= htmlspecialchars($b['nama_barang']) ?> (stok: <?= $b['stok'] ?>)
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <small class="stok-info" style="color:var(--gray-400);font-size:.72rem"></small>
                                </td>
                                <td><input type="number" name="jumlah[]" class="form-control qty-input" min="1" value="1"></td>
                                <td><input type="number" name="harga[]" class="form-control harga-input" min="0" value="0"></td>
                                <td><span class="subtotal-display">Rp 0</span><input type="hidden" name="subtotal[]" class="subtotal-input" value="0"></td>
                                <td><button type="button" class="btn btn-danger btn-sm btn-icon remove-row"><i class="fas fa-times"></i></button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div style="text-align:right;padding:8px 12px;background:var(--gray-50);border-radius:0 0 8px 8px;border:1px solid var(--gray-200);border-top:none">
                    <strong>Total: <span id="grandTotal" style="color:var(--primary)">Rp 0</span></strong>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%">
                <i class="fas fa-save"></i> Simpan Transaksi Keluar
            </button>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fas fa-list"></i> Riwayat Barang Keluar</div>
    </div>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr><th>No. Transaksi</th><th>Tanggal</th><th>Item</th><th>Nilai</th><th>Oleh</th><th></th></tr>
            </thead>
            <tbody>
            <?php if ($transaksis): foreach ($transaksis as $tx): ?>
            <tr>
                <td><code style="font-size:.75rem"><?= htmlspecialchars($tx['no_transaksi']) ?></code></td>
                <td><?= date('d/m/Y', strtotime($tx['tanggal'])) ?></td>
                <td><?= $tx['jumlah_item'] ?> item</td>
                <td style="font-weight:600;color:#3b82f6"><?= formatRupiah($tx['total_nilai'] ?? 0) ?></td>
                <td style="font-size:.8rem"><?= htmlspecialchars($tx['user_nama'] ?? '-') ?></td>
                <td><a href="cetak_transaksi.php?id=<?= $tx['id'] ?>" class="btn btn-outline btn-sm" target="_blank"><i class="fas fa-print"></i></a></td>
            </tr>
            <?php endforeach; else: ?>
            <tr><td colspan="6"><div class="empty-state"><i class="fas fa-arrow-up"></i><h3>Belum ada transaksi keluar</h3></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>

<template id="item-row-template">
    <tr class="detail-row">
        <td>
            <select name="barang_id[0]" class="form-control barang-select">
                <option value="">— Pilih —</option>
                <?php foreach ($barangs as $b): ?>
                <option value="<?= $b['id'] ?>" data-stok="<?= $b['stok'] ?>" data-satuan="<?= $b['satuan'] ?>" data-harga="<?= $b['harga_jual'] ?>">
                    <?= htmlspecialchars($b['nama_barang']) ?> (stok: <?= $b['stok'] ?>)
                </option>
                <?php endforeach; ?>
            </select>
            <small class="stok-info" style="color:var(--gray-400);font-size:.72rem"></small>
        </td>
        <td><input type="number" name="jumlah[0]" class="form-control qty-input" min="1" value="1"></td>
        <td><input type="number" name="harga[0]" class="form-control harga-input" min="0" value="0"></td>
        <td><span class="subtotal-display">Rp 0</span><input type="hidden" name="subtotal[0]" class="subtotal-input" value="0"></td>
        <td><button type="button" class="btn btn-danger btn-sm btn-icon remove-row"><i class="fas fa-times"></i></button></td>
    </tr>
</template>

<script>
$(function () {
    function fRp(n) {
        return "Rp " + Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }
    function hitungBaris($row) {
        var qty   = parseFloat($row.find(".qty-input").val())   || 0;
        var harga = parseFloat($row.find(".harga-input").val()) || 0;
        var sub   = qty * harga;
        $row.find(".subtotal-display").text(fRp(sub));
        $row.find(".subtotal-input").val(sub);
    }
    function hitungTotal() {
        var total = 0;
        $(".subtotal-input").each(function () { total += parseFloat($(this).val()) || 0; });
        $("#grandTotal").text(fRp(total));
    }
    $(document).on("change", ".barang-select", function () {
        var $row = $(this).closest("tr");
        var $opt = $(this).find("option:selected");
        var harga = parseFloat($opt.data("harga")) || 0;
        var stok  = $opt.data("stok") !== undefined ? $opt.data("stok") : "-";
        var sat   = $opt.data("satuan") || "";
        $row.find(".harga-input").val(harga);
        $row.find(".stok-info").text($opt.val() ? "Stok: " + stok + " " + sat : "");
        hitungBaris($row);
        hitungTotal();
    });
    $(document).on("input", ".qty-input, .harga-input", function () {
        hitungBaris($(this).closest("tr"));
        hitungTotal();
    });
    var rowIndex = $(".detail-row").length;
    $(document).on("click", "#addRow, [data-add-row]", function () {
        var tpl   = document.getElementById("item-row-template");
        var clone = tpl.innerHTML.replace(/\[0\]/g, "[" + rowIndex + "]");
        $("#items-tbody").append(clone);
        rowIndex++;
    });
    $(document).on("click", ".remove-row", function () {
        if ($(".detail-row").length > 1) {
            $(this).closest("tr").remove();
            hitungTotal();
        }
    });
    $(".detail-row").each(function () { hitungBaris($(this)); });
    hitungTotal();
});
</script>

<?php include '../includes/footer.php'; ?>