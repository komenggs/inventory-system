<?php
/**
 * Perbaiki password demo (admin/staff → password).
 * Buka sekali via browser, lalu hapus file ini.
 */
require_once __DIR__ . '/config.php';

$hash = password_hash('password', PASSWORD_DEFAULT);
$stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username IN ('admin', 'staff')");
$stmt->execute([$hash]);
$updated = $stmt->rowCount();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Reset Password — <?= APP_NAME ?></title>
    <style>body{font-family:sans-serif;max-width:480px;margin:60px auto;padding:24px;line-height:1.6}</style>
</head>
<body>
    <h2>Password demo diperbarui</h2>
    <p><?= (int)$updated ?> akun (admin / staff) sekarang memakai password: <strong>password</strong></p>
    <p><a href="<?= base_url('index.php') ?>">Ke halaman login</a></p>
    <p style="color:#b91c1c;font-size:.9rem"><strong>Hapus file reset_password.php</strong> setelah ini untuk keamanan.</p>
</body>
</html>
