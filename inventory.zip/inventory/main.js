/**
 * Gudang Mengs — main.js
 * Menangani: modal, konfirmasi hapus, sidebar toggle, kalkulasi transaksi
 */

$(function () {
  // ============================================
  // MODAL
  // ============================================

  // Buka modal via data-modal="idModal"
  $(document).on("click", "[data-modal]", function (e) {
    e.preventDefault();
    const id = $(this).data("modal");
    $("#" + id).addClass("active");
  });

  // Tutup modal via tombol .modal-close atau data-dismiss="modal"
  $(document).on("click", '.modal-close, [data-dismiss="modal"]', function () {
    $(this).closest(".modal-overlay").removeClass("active");
  });

  // Tutup modal klik overlay (luar modal)
  $(document).on("click", ".modal-overlay", function (e) {
    if ($(e.target).hasClass("modal-overlay")) {
      $(this).removeClass("active");
    }
  });

  // Tutup dengan ESC
  $(document).on("keydown", function (e) {
    if (e.key === "Escape") {
      $(".modal-overlay.active").removeClass("active");
    }
  });

  // ============================================
  // KONFIRMASI HAPUS
  // ============================================

  $(document).on("click", ".btn-delete", function (e) {
    const nama = $(this).data("nama") || "item ini";
    if (
      !confirm(
        "Yakin ingin menghapus " +
          nama +
          "?\nTindakan ini tidak dapat dibatalkan.",
      )
    ) {
      e.preventDefault();
      return false;
    }
  });

  // ============================================
  // SIDEBAR TOGGLE (mobile)
  // ============================================

  $("#toggleSidebar").on("click", function () {
    $("#sidebar").toggleClass("open");
    $("body").toggleClass("sidebar-open");
  });

  // Tutup sidebar klik di luar (mobile)
  $(document).on("click", function (e) {
    if ($(window).width() < 992) {
      if (!$(e.target).closest("#sidebar, #toggleSidebar").length) {
        $("#sidebar").removeClass("open");
        $("body").removeClass("sidebar-open");
      }
    }
  });

  // ============================================
  // ALERT AUTO-DISMISS
  // ============================================

  setTimeout(function () {
    $(".alert").fadeOut(500);
  }, 4000);

  // ============================================
  // KALKULASI TRANSAKSI (masuk & keluar)
  // ============================================

  function hitungSubtotal($row) {
    const qty = parseFloat($row.find(".qty-input").val()) || 0;
    const harga = parseFloat($row.find(".harga-input").val()) || 0;
    const sub = qty * harga;
    $row.find(".subtotal-display").text(formatRupiah(sub));
    $row.find(".subtotal-input").val(sub);
    hitungGrandTotal();
  }

  function hitungGrandTotal() {
    let grand = 0;
    $(".subtotal-input").each(function () {
      grand += parseFloat($(this).val()) || 0;
    });
    $("#grandTotal").text(formatRupiah(grand));
  }

  function formatRupiah(angka) {
    return "Rp " + Math.round(angka).toLocaleString("id-ID");
  }

  // Qty berubah
  $(document).on("input", ".qty-input", function () {
    hitungSubtotal($(this).closest("tr"));
  });

  // Harga berubah
  $(document).on("input", ".harga-input", function () {
    hitungSubtotal($(this).closest("tr"));
  });

  // Pilih barang → isi harga otomatis
  $(document).on("change", ".barang-select", function () {
    const $opt = $(this).find("option:selected");
    const $row = $(this).closest("tr");
    const harga = $opt.data("harga") || 0;
    const stok = $opt.data("stok");
    const satuan = $opt.data("satuan") || "";

    $row.find(".harga-input").val(harga);

    if (stok !== undefined) {
      $row.find(".stok-info").text("Stok: " + stok + " " + satuan);
    } else {
      $row.find(".stok-info").text("");
    }

    hitungSubtotal($row);
  });

  // Tambah baris item
  $("#addItemRow").on("click", function () {
    const $template = $("#item-row-template");
    if (!$template.length) return;

    const $clone = $($template.html());
    const idx = $("#items-table tbody tr").length;

    // Ganti index placeholder [0] dengan index sebenarnya
    $clone.find("[name]").each(function () {
      const name = $(this)
        .attr("name")
        .replace("[0]", "[" + idx + "]");
      $(this).attr("name", name);
    });

    $("#items-table tbody").append($clone);
  });

  // Hapus baris item
  $(document).on("click", ".remove-row", function () {
    const $tbody = $("#items-table tbody");
    if ($tbody.find("tr").length > 1) {
      $(this).closest("tr").remove();
      hitungGrandTotal();
    } else {
      alert("Minimal harus ada satu baris barang.");
    }
  });

  // ============================================
  // FORMAT INPUT HARGA (opsional: bersihkan titik/koma saat submit)
  // ============================================

  $("form").on("submit", function () {
    $(this)
      .find(".harga-input")
      .each(function () {
        let val = $(this).val().replace(/\./g, "").replace(",", ".");
        $(this).val(val);
      });
  });
});
